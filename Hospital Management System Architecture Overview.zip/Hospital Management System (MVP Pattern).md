# Hospital Management System (MVP Pattern)

This project implements a simple Hospital Management System using the Model-View-Presenter (MVP) architectural pattern. The system is built with Python and uses SQLite for data storage.

## Table of Contents
1.  [Introduction](#introduction)
2.  [Architecture (MVP)](#architecture-mvp)
3.  [Technology Stack](#technology-stack)
4.  [Project Structure](#project-structure)
5.  [Class Diagram](#class-diagram)
6.  [How to Run](#how-to-run)
7.  [Unit Tests](#unit-tests)

## 1. Introduction
This application demonstrates a clear separation of concerns for a hospital management system, focusing on patient, doctor, appointment, and invoice management. The MVP pattern ensures that the business logic is independent of the user interface, making the system scalable, testable, and maintainable.

## 2. Architecture (MVP)
The project is structured around the Model-View-Presenter (MVP) pattern:

-   **Model**: Manages the data and business logic. It defines the data structures (Patient, Doctor, Appointment, Invoice) and handles data persistence through a `DatabaseHelper` class.
-   **View**: The user interface. It displays data to the user and captures user input. The `IHospitalView` interface defines the contract for any view implementation, and `ConsoleView` provides a basic console-based interface.
-   **Presenter**: Acts as a mediator between the Model and the View. It contains the application's business logic, responds to user actions from the View, retrieves and manipulates data via the Model, and updates the View accordingly. The Presenter has no direct dependency on any specific UI framework.

### Why MVP for this project?
-   **Separation of Concerns**: The clear division between Model, View, and Presenter allows for independent development and modification of each component. For instance, the UI can be changed (e.g., from console to web) without affecting the core business logic.
-   **Scalability**: New modules or features (e.g., a Pharmacy Module) can be added by creating new Models and Presenters, integrating seamlessly with the existing architecture.
-   **Testability**: The Presenter, containing the core logic, can be easily unit-tested by mocking the View and Model interfaces, ensuring robust and reliable functionality.

## 3. Technology Stack
-   **Language**: Python 3.x
-   **Storage**: SQLite (file-based relational database)

## 4. Project Structure
```
. 
├── main.py
├── model.py
├── presenter.py
├── view.py
├── test_presenter.py
├── class_diagram.mmd
└── class_diagram.png
```

-   `model.py`: Contains data models (Patient, Doctor, Appointment, Invoice) and `DatabaseHelper` for SQLite CRUD operations.
-   `view.py`: Defines the `IHospitalView` interface and provides a `ConsoleView` implementation.
-   `presenter.py`: Implements the `HospitalPresenter` with business logic, mediating between the View and Model.
-   `main.py`: The entry point of the application, wiring together the View, Model, and Presenter.
-   `test_presenter.py`: Unit tests for the `HospitalPresenter`.
-   `class_diagram.mmd`: Mermaid diagram definition for the class structure.
-   `class_diagram.png`: Rendered image of the class diagram.

## 5. Class Diagram
Below is the class diagram illustrating the relationships and interactions between the different components of the system:

![Class Diagram](https://private-us-east-1.manuscdn.com/sessionFile/zwtWGmQmBa3UD8GXtZ6Gct/sandbox/SqPfFu4G4JC1hzeqJ7NHni-images_1775098238682_na1fn_L2hvbWUvdWJ1bnR1L2NsYXNzX2RpYWdyYW0.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvend0V0dtUW1CYTNVRDhHWHRaNkdjdC9zYW5kYm94L1NxUGZGdTRHNEpDMWh6ZXFKN05IbmktaW1hZ2VzXzE3NzUwOTgyMzg2ODJfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyTnNZWE56WDJScFlXZHlZVzAucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=rKaD3qHTBo6BqprjSEWimvHdmUg0bgHyeR72YuPF55Ycf4x9915WnpT-1iu8O30FK116qqaZMsbDdctgeDDYvCIVzSr7Bp3HrWOpqe9C0wDgDC8kfXZ5pTdZu9iuBaM1TgptE4dvvuqrh03fNAOfBBZZEj~grM7T3tw9Qg4ee34iAZwRZMPFRHN8aEFsLqBy3kXmd1ymwm9JWtzwafj6ZSrADvPM46VTDJyjULUffEk6m-clVOEWuOstKJXPoeTCDddHVL4H9S52i8tYUX20HWNs4k34RAUVatnEc~SB3bqB2ZCrVIc6UP0lfs24lUBU~B4oRzKUKJ4lH3oW~HFCRg__)

## 6. How to Run
1.  **Save the files**: Ensure `model.py`, `view.py`, `presenter.py`, and `main.py` are in the same directory.
2.  **Run the application**: Open a terminal or command prompt in that directory and execute:
    ```bash
    python3 main.py
    ```
3.  **Interact**: Follow the on-screen prompts in the console to interact with the Hospital Management System.

## 7. Unit Tests
To run the unit tests for the Presenter layer, execute the following command in the project directory:

```bash
python3 test_presenter.py
```

This will run tests that verify the Presenter's logic independently of the UI and database, using mock objects for the View and DatabaseHelper.
